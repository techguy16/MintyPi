__version__ = "2.0.0"

"""Collection of classes shared by Mint packages."""

__all__ = ["cache", "installer", "_apt", "_flatpak", "dialogs", "misc"]