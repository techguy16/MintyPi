# Generated file - DO NOT EDIT.  Edit config.py.in instead.

prefix="/usr"
datadir="/usr/share"
localedir=datadir+"/locale"
pkgdatadir="/usr/share/cinnamon-screensaver"
libdir="/usr/lib/aarch64-linux-gnu"
libexecdir="/usr/lib/aarch64-linux-gnu/cinnamon-screensaver"
PACKAGE="cinnamon-screensaver"
VERSION="5.2.1"
GETTEXT_PACKAGE="cinnamon-screensaver"
