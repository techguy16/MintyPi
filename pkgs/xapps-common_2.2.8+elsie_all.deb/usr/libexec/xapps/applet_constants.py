LOCALEDIR = "/usr/share/locale"
PKGVERSION = "2.2.8"